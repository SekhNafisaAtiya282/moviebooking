﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using Microsoft.Extensions.Primitives;
using MovieBookingApp.Filters;
using MovieBookingApp.Interfaces.IBusiness;
using MovieBookingApp.Models;
using System.IdentityModel.Tokens.Jwt;
using System.IO;
using System.Net.Sockets;
using System.Security.Claims;

namespace MovieBookingApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    //[Authorize]
    public class MovieBookingController : ControllerBase
    {
        private readonly IUserBusiness _userBusiness;
        private readonly IMovieBusiness _movieBusiness;
        private readonly ITicketBusiness _ticketBusiness;

        public MovieBookingController(IUserBusiness userBusiness, IMovieBusiness movieBusiness, ITicketBusiness ticketBusiness)
        {
            _userBusiness = userBusiness;
            _movieBusiness = movieBusiness;
            _ticketBusiness = ticketBusiness;
        }

        [HttpPost("Register")]
        [ServiceFilter(typeof(NullCheckFilter))]
        public async Task<ActionResult> Register(UserDto user)
        {
            var userId = await _userBusiness.AddUser(user);

            if (!string.IsNullOrEmpty(userId))
            {
                return Created("", userId);
            }
            else
            {
                return BadRequest("User already exists");
            }
        }

        [HttpGet("Login")]
        public async Task<ActionResult<string>> Login(string loginId, string password)
        {
            var token = await _userBusiness.GetUserToken(loginId, password);

            if (!string.IsNullOrEmpty(token))
            {
                return Ok(token);
            }
            else
            {
                return BadRequest("Incorrect LoginId or Password");
            }
        }

        [Authorize]
        [HttpGet("{loginId}/Forgot")]
        public async Task<ActionResult<string>> Forgot(string loginId, string newPassword)
        {
            StringValues headerValues;
            Request.Headers.TryGetValue("Authorization", out headerValues);
            var result = await _userBusiness.ValidateRequest(loginId, headerValues);

            switch(result.ToLower())
            {
                case "bad request": return BadRequest();
                case "invalid request": return Unauthorized();
            }

            var passwordChangedStatus = await _userBusiness.ChangePassword(loginId, newPassword);
            
            if (!string.IsNullOrEmpty(passwordChangedStatus))
            {
                return Ok(passwordChangedStatus);
            }
            return BadRequest(passwordChangedStatus);
        }

        [HttpGet("{loginId}/changePassword")]
        public async Task<ActionResult<string>> ChangePassword(string loginId, string oldPassword, string newPassword)
        {
            var passwordChangedStatus = await _userBusiness.ChangePassword(loginId, oldPassword, newPassword);
            
            if (!string.IsNullOrEmpty(passwordChangedStatus))
            {
                return Ok(passwordChangedStatus);
            }
            return BadRequest(passwordChangedStatus);
        }

        [Authorize]
        [HttpGet("All")]
        public async Task<ActionResult<List<MovieDto>>> ViewAllMovies()
        {
            List<MovieDto>? movies = await _movieBusiness.GetMovies();

            if (movies is not null && movies.Count > 0)
            {
                return Ok(movies);
            }
            return NoContent();
        }
        [Authorize]
        [HttpGet("Movies/Search/MovieName")]
        public async Task<ActionResult<MovieDto>> SearchMovie(string movieName)
        {
            var movies = await _movieBusiness.SearchMovie(movieName);

            if (movies is not null && movies.Count > 0)
            {
                return Ok(movies);
            }
            return NoContent();
        }

        [Authorize]
        [HttpPost("ticket/bookticket")]
        [ServiceFilter(typeof(NullCheckFilter))]
        public async Task<ActionResult<string>> AddTickets(TicketDto ticket)
        {
            string status = null;

            if(ticket.NumberOfTickets > 0)
                status = await _ticketBusiness.AddTicket(ticket);

            if (!string.IsNullOrEmpty(status))
            {
                return Ok(status);
            }
            return BadRequest(status);
        }

        [Authorize("Admin")]
        [HttpPost("movie/add")]
        [ServiceFilter(typeof(NullCheckFilter))]
        public async Task<ActionResult<string>> AddMovie(Movie movie)
        {
            string status = null;

            if (movie.TicketsAlloted > 0 && movie.TicketsBooked >= 0)
                status = await _movieBusiness.AddMovie(movie);

            if (!string.IsNullOrEmpty(status))
            {
                return Ok(status);
            }
            return BadRequest(status);
        }

        [Authorize]
        [HttpGet("ticket/delete/{id}")]
        [ServiceFilter(typeof(NullCheckFilter))]
        public async Task<ActionResult<string>> DeleteTickets([FromRoute]string id = null)
        {
            var status = await _ticketBusiness.DeleteTicket(id);

            if (!string.IsNullOrEmpty(status))
            {
                return Ok(status);
            }
            return BadRequest(status);
        }

        [Authorize]
        [HttpPost("ticket/update")]
        [ServiceFilter(typeof(NullCheckFilter))]
        public async Task<ActionResult<string>> UpdateTicket(Ticket ticket)
        {
            string status = null;

            if (ticket.NumberOfTickets > 0)
                status = await _ticketBusiness.UpdateTicket(ticket);

            if (!string.IsNullOrEmpty(status))
            {
                return Ok(status);
            }
            return BadRequest(status);
        }

    }
}
